<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->yieldContent('navbar'); ?>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0, shrink-to-fit-no" name="viewport">

	<title>Exemplo de Bootsrap</title>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
</head>

<body>
    <!--barra de navegação-->
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="http://localhost/materiais"><b><FONT COLOR="#AA0000">Projecto PSI</FONT></b></a>
        <button class="navbar-toggler"type="button"data-toogle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toogle navigation">
        <span class="navbar-tooggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse"id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('materiais.index')); ?>"><b><FONT COLOR="#00AA00">Materiais</FONT></b><span class="sr-only">(atual)</span>
                </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('requisicoes.index')); ?>"><b><FONT COLOR="#00AA00">Requisicoes</FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('requisitantes.index')); ?>"><b><FONT COLOR="#00AA00">Requisitantes</FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('TiposRequisitantes.index')); ?>"><b><FONT COLOR="#00AA00"></FONT></b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('TiposEquips.index')); ?>"><b><FONT COLOR="#00AA00"></FONT></b></a>
            </li>
            
            <li class="nav-item dropdown">

                

                <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="#">Item</a>
                 <a class="dropdown-item" href="#">Outro item</a>
                <a class="dropdown-item" href="#">Algum outro item</a>
                </div>
            </li>
            </ul>
    
        </div>
    </nav>

    <?php echo $__env->yieldContent('menu'); ?>
    <main role="main">
        
    <div class="jumbotron">
        <div class="container">
             <div class="text-center">
        <h1 class="display-3"><FONT COLOR="#00AA00">Projeto Modulo 18</FONT></h1>
            
        <p><FONT COLOR="#0000AA">Afonso Valente / Nº1 / 12I2</p>
           
              <br>
                 <br>
        </div>
        </div>
        </div>
        
       
        <?php echo $__env->yieldContent('conteudo'); ?>
        </div>
        </div>
        <hr>
        <?php echo $__env->yieldContent('rodapé'); ?>

        <p text align="center"><img src="dormrm.gif" width="500"></p>
        
        
       
      <br>
        </main>
     <div class="text-center">
        <footer class="container">
        <p>&copy;Companhia GPSI 2020-2021</p>
        </footer>
    </div>
    
    

    </body>
</html><?php /**PATH C:\Users\avale\Desktop\Projeto18atualizado-main\Projeto PSI\projeto\resources\views/layout.blade.php ENDPATH**/ ?>