
<?php $__env->startSection('nabvar'); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>


<ul>
<?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('materiais.show', ['id'=>$material->id_material])); ?>">
 <?php echo e($material->designacao); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($materiais->render()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\avale\Desktop\Projeto18atualizado-main\Projeto PSI\projeto\resources\views/materiais/index.blade.php ENDPATH**/ ?>