<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->yieldContent('navbar'); ?>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0, shrink-to-fit-no" name="viewport">

	<title>Exemplo de Bootsrap</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!--barra de navegação-->
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="http://localhost/materiais"><b>Projeto PSI</b></a>
        <button class="navbar-toggler"type="button"data-toogle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toogle navigation">
        <span class="navbar-tooggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse"id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('materiais.index')); ?>"><b>Materiais</b><span class="sr-only">(atual)</span>
                </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('requisicoes.index')); ?>"><b>Requisicoes</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('requisitantes.index')); ?>"><b>Requisitantes</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('TiposRequisitantes.index')); ?>"><b>Tipos Equipamentos</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('TiposEquips.index')); ?>"><b>Tipos Requisitantes</b></a>
            </li>
            
            <li class="nav-item dropdown">

                

                <div class="dropdown-menu" aria-labelledby="dropdown01">
                <a class="dropdown-item" href="#">Item</a>
                 <a class="dropdown-item" href="#">Outro item</a>
                <a class="dropdown-item" href="#">Algum outro item</a>
                </div>
            </li>
            </ul>
    
        </div>
    </nav>

    <?php echo $__env->yieldContent('menu'); ?>
    <main role="main">
        
    <div class="jumbotron">
        <div class="container">
             <div class="text-center">
        <h1 class="display-3">Projeto Modulo 18</h1>
            
        <p>Afonso Valente / Nº1 / 12I2</p>
           
              <br>
                 <br>
        </div>
        </div>
        </div>
        
       
        <?php echo $__env->yieldContent('conteudo'); ?>
        </div>
        </div>
        <hr>
        <?php echo $__env->yieldContent('rodapé'); ?>

        
        <p align="center"><img src="dormrm.gif" alt="some text" width=500 height=250></p>
       
      <br>
        </main>
     <div class="text-center">
        <footer class="container">
        <p>&copy;Companhia GPSI 2020-2021</p>
        </footer>
    </div>
    
    
    <script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.js"></script>
    </body>
</html><?php /**PATH C:\Users\avale\Desktop\Projeto PSI\projeto\resources\views/layout.blade.php ENDPATH**/ ?>