<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Requisicao;
class RequisicoesController extends Controller
{
   public function index(){

	$requisicao= Requisicao::paginate(10);

	return view ('requisicoes.index', ['requisicoes'=>$requisicao]);
}
public function show (Request $request){
	$idRequisicao=$request->id;


	$requisicao=Requisicao::where('id_requisicao', $idRequisicao)->with('requisitantes')->first();
	
	return view ('requisicoes.show',['requisicao'=>$requisicao]);
}
}
