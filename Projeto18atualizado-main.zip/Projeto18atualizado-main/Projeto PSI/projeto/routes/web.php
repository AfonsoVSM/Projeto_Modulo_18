<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

route::get('/materiais', 'App\http\Controllers\MateriaisController@index')->name('materiais.index');

route::get('/materiais/{id}/show', 'App\Http\Controllers\MateriaisController@show')->name('materiais.show');

route::get('/requisicoes', 'App\http\Controllers\RequisicoesController@index')->name('requisicoes.index');

route::get('/requisicoes/{id}/show', 'App\Http\Controllers\RequisicoesController@show')->name('requisicoes.show');

route::get('/requisitantes', 'App\http\Controllers\RequisitantesController@index')->name('requisitantes.index');

route::get('/requisitantes/{id}/show', 'App\Http\Controllers\RequisitantesController@show')->name('requisitantes.show');

route::get('/TiposEquips', 'App\http\Controllers\TiposEquipsController@index')->name('TiposEquips.index');

route::get('/TiposEquips/{id}/show', 'App\Http\Controllers\TiposEquipsController@show')->name('TiposEquips.show');

route::get('/TiposRequisitantes', 'App\http\Controllers\TiposRequisitantesController@index')->name('TiposRequisitantes.index');

route::get('/TiposRequisitantes/{id}/show', 'App\Http\Controllers\TiposRequisitantesController@show')->name('TiposRequisitantes.show');

