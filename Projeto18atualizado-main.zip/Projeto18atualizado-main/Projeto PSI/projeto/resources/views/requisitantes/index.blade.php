@extends('layout')
@section('nabvar')
@endsection
@section('menu')
@endsection

@section('conteudo')


<ul>
@foreach($requisitantes as $requisitante)
<li>
<a href="{{route('requisitantes.show', ['id'=>$requisitante->id_requisitante])}}">
 {{$requisitante->nome}}</a></li>
@endforeach
</ul>
{{$requisitantes->render()}}

@endsection

@section('rodapé')

@endsection
