@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('conteudo')

<ul>
@foreach($requisicoes as $requisicao)
<li>
<a href="{{route('requisicoes.show', ['id'=>$requisicao->id_requisicao])}}">
 {{$requisicao->observacoes}}</a></li>
@endforeach
</ul>
{{$requisicoes->render()}}

@endsection

@section('rodapé')

@endsection
