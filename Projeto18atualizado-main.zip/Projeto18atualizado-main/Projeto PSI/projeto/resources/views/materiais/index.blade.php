@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('conteudo')


<ul>
@foreach($materiais as $material)
<li>
<a href="{{route('materiais.show', ['id'=>$material->id_material])}}">
 {{$material->designacao}}</a></li>
@endforeach
</ul>
{{$materiais->render()}}

@endsection

@section('rodapé')

@endsection
